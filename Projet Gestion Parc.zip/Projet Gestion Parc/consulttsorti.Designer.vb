﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class consulttsorti
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(consulttsorti))
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ConsultationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LesSortiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.GestionDesAjoutsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AjouterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConducteurToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MotifToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoitureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TypeDentretienToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NouvelleSortieToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tabconsul = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.DataGridViewSorti = New System.Windows.Forms.DataGridView()
        Me.NumsortieDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DatsortieDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ImmvoituDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LibmotifDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NoconducDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KmdepartDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KmarriveDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CbrtDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.EntrDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.KmparcouruDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MontantentrDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MontantcbrtDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DepjrfcfaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TsortieBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BDGestParcBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BDGestParc = New ProjBDGestParc.BDGestParc()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DataGridViewVoitu = New System.Windows.Forms.DataGridView()
        Me.ImmvoituDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MarqvoituDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Puissce100DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TypcbrtDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TvoituBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Combovoitu = New System.Windows.Forms.ComboBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TsortieBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TsortieTableAdapter = New ProjBDGestParc.BDGestParcTableAdapters.TsortieTableAdapter()
        Me.TvoituTableAdapter = New ProjBDGestParc.BDGestParcTableAdapters.TvoituTableAdapter()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.Tabconsul.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridViewSorti, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TsortieBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BDGestParcBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BDGestParc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridViewVoitu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TvoituBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TsortieBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.BindingNavigator1.CountItem = Me.BindingNavigatorCountItem
        Me.BindingNavigator1.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem})
        Me.BindingNavigator1.Location = New System.Drawing.Point(0, 0)
        Me.BindingNavigator1.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.BindingNavigator1.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.BindingNavigator1.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.BindingNavigator1.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.BindingNavigatorPositionItem
        Me.BindingNavigator1.Size = New System.Drawing.Size(904, 25)
        Me.BindingNavigator1.TabIndex = 23
        Me.BindingNavigator1.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Ajouter nouveau"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Nombre total d'éléments"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Supprimer"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Placer en premier"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Position actuelle"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Déplacer vers le bas"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Placer en dernier"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Tomato
        Me.Button2.Location = New System.Drawing.Point(877, 0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(27, 23)
        Me.Button2.TabIndex = 28
        Me.Button2.Text = "X"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.MenuStrip1)
        Me.GroupBox1.Controls.Add(Me.MenuStrip2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 101)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(229, 75)
        Me.GroupBox1.TabIndex = 31
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Menu Général"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConsultationsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(3, 40)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(223, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ConsultationsToolStripMenuItem
        '
        Me.ConsultationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LesSortiesToolStripMenuItem})
        Me.ConsultationsToolStripMenuItem.Name = "ConsultationsToolStripMenuItem"
        Me.ConsultationsToolStripMenuItem.Size = New System.Drawing.Size(92, 20)
        Me.ConsultationsToolStripMenuItem.Text = "Consultations"
        '
        'LesSortiesToolStripMenuItem
        '
        Me.LesSortiesToolStripMenuItem.Name = "LesSortiesToolStripMenuItem"
        Me.LesSortiesToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.LesSortiesToolStripMenuItem.Text = "les sorties"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GestionDesAjoutsToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(3, 16)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(223, 24)
        Me.MenuStrip2.TabIndex = 1
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'GestionDesAjoutsToolStripMenuItem
        '
        Me.GestionDesAjoutsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AjouterToolStripMenuItem})
        Me.GestionDesAjoutsToolStripMenuItem.Name = "GestionDesAjoutsToolStripMenuItem"
        Me.GestionDesAjoutsToolStripMenuItem.Size = New System.Drawing.Size(115, 20)
        Me.GestionDesAjoutsToolStripMenuItem.Text = "Gestion des ajouts"
        '
        'AjouterToolStripMenuItem
        '
        Me.AjouterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConducteurToolStripMenuItem, Me.MotifToolStripMenuItem, Me.VoitureToolStripMenuItem, Me.TypeDentretienToolStripMenuItem, Me.NouvelleSortieToolStripMenuItem})
        Me.AjouterToolStripMenuItem.Name = "AjouterToolStripMenuItem"
        Me.AjouterToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.AjouterToolStripMenuItem.Text = "Ajouter"
        '
        'ConducteurToolStripMenuItem
        '
        Me.ConducteurToolStripMenuItem.Name = "ConducteurToolStripMenuItem"
        Me.ConducteurToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.ConducteurToolStripMenuItem.Text = "conducteur"
        '
        'MotifToolStripMenuItem
        '
        Me.MotifToolStripMenuItem.Name = "MotifToolStripMenuItem"
        Me.MotifToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.MotifToolStripMenuItem.Text = "motif"
        '
        'VoitureToolStripMenuItem
        '
        Me.VoitureToolStripMenuItem.Name = "VoitureToolStripMenuItem"
        Me.VoitureToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.VoitureToolStripMenuItem.Text = "voiture"
        '
        'TypeDentretienToolStripMenuItem
        '
        Me.TypeDentretienToolStripMenuItem.Name = "TypeDentretienToolStripMenuItem"
        Me.TypeDentretienToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.TypeDentretienToolStripMenuItem.Text = "type d'entretien"
        '
        'NouvelleSortieToolStripMenuItem
        '
        Me.NouvelleSortieToolStripMenuItem.Name = "NouvelleSortieToolStripMenuItem"
        Me.NouvelleSortieToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.NouvelleSortieToolStripMenuItem.Text = "Nouvelle sortie"
        '
        'Tabconsul
        '
        Me.Tabconsul.Controls.Add(Me.TabPage1)
        Me.Tabconsul.Controls.Add(Me.TabPage2)
        Me.Tabconsul.Location = New System.Drawing.Point(247, 29)
        Me.Tabconsul.Name = "Tabconsul"
        Me.Tabconsul.SelectedIndex = 0
        Me.Tabconsul.Size = New System.Drawing.Size(645, 424)
        Me.Tabconsul.TabIndex = 32
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.DataGridViewSorti)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(637, 398)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Recherche/voiture"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'DataGridViewSorti
        '
        Me.DataGridViewSorti.AutoGenerateColumns = False
        Me.DataGridViewSorti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewSorti.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NumsortieDataGridViewTextBoxColumn, Me.DatsortieDataGridViewTextBoxColumn, Me.ImmvoituDataGridViewTextBoxColumn, Me.LibmotifDataGridViewTextBoxColumn, Me.NoconducDataGridViewTextBoxColumn, Me.KmdepartDataGridViewTextBoxColumn, Me.KmarriveDataGridViewTextBoxColumn, Me.CbrtDataGridViewCheckBoxColumn, Me.EntrDataGridViewCheckBoxColumn, Me.KmparcouruDataGridViewTextBoxColumn, Me.MontantentrDataGridViewTextBoxColumn, Me.MontantcbrtDataGridViewTextBoxColumn, Me.DepjrfcfaDataGridViewTextBoxColumn})
        Me.DataGridViewSorti.DataSource = Me.TsortieBindingSource1
        Me.DataGridViewSorti.Location = New System.Drawing.Point(6, 120)
        Me.DataGridViewSorti.Name = "DataGridViewSorti"
        Me.DataGridViewSorti.Size = New System.Drawing.Size(625, 257)
        Me.DataGridViewSorti.TabIndex = 1
        '
        'NumsortieDataGridViewTextBoxColumn
        '
        Me.NumsortieDataGridViewTextBoxColumn.DataPropertyName = "numsortie"
        Me.NumsortieDataGridViewTextBoxColumn.HeaderText = "numsortie"
        Me.NumsortieDataGridViewTextBoxColumn.Name = "NumsortieDataGridViewTextBoxColumn"
        '
        'DatsortieDataGridViewTextBoxColumn
        '
        Me.DatsortieDataGridViewTextBoxColumn.DataPropertyName = "datsortie"
        Me.DatsortieDataGridViewTextBoxColumn.HeaderText = "datsortie"
        Me.DatsortieDataGridViewTextBoxColumn.Name = "DatsortieDataGridViewTextBoxColumn"
        '
        'ImmvoituDataGridViewTextBoxColumn
        '
        Me.ImmvoituDataGridViewTextBoxColumn.DataPropertyName = "immvoitu"
        Me.ImmvoituDataGridViewTextBoxColumn.HeaderText = "immvoitu"
        Me.ImmvoituDataGridViewTextBoxColumn.Name = "ImmvoituDataGridViewTextBoxColumn"
        '
        'LibmotifDataGridViewTextBoxColumn
        '
        Me.LibmotifDataGridViewTextBoxColumn.DataPropertyName = "libmotif"
        Me.LibmotifDataGridViewTextBoxColumn.HeaderText = "libmotif"
        Me.LibmotifDataGridViewTextBoxColumn.Name = "LibmotifDataGridViewTextBoxColumn"
        '
        'NoconducDataGridViewTextBoxColumn
        '
        Me.NoconducDataGridViewTextBoxColumn.DataPropertyName = "noconduc"
        Me.NoconducDataGridViewTextBoxColumn.HeaderText = "noconduc"
        Me.NoconducDataGridViewTextBoxColumn.Name = "NoconducDataGridViewTextBoxColumn"
        '
        'KmdepartDataGridViewTextBoxColumn
        '
        Me.KmdepartDataGridViewTextBoxColumn.DataPropertyName = "kmdepart"
        Me.KmdepartDataGridViewTextBoxColumn.HeaderText = "kmdepart"
        Me.KmdepartDataGridViewTextBoxColumn.Name = "KmdepartDataGridViewTextBoxColumn"
        '
        'KmarriveDataGridViewTextBoxColumn
        '
        Me.KmarriveDataGridViewTextBoxColumn.DataPropertyName = "kmarrive"
        Me.KmarriveDataGridViewTextBoxColumn.HeaderText = "kmarrive"
        Me.KmarriveDataGridViewTextBoxColumn.Name = "KmarriveDataGridViewTextBoxColumn"
        '
        'CbrtDataGridViewCheckBoxColumn
        '
        Me.CbrtDataGridViewCheckBoxColumn.DataPropertyName = "cbrt"
        Me.CbrtDataGridViewCheckBoxColumn.HeaderText = "cbrt"
        Me.CbrtDataGridViewCheckBoxColumn.Name = "CbrtDataGridViewCheckBoxColumn"
        '
        'EntrDataGridViewCheckBoxColumn
        '
        Me.EntrDataGridViewCheckBoxColumn.DataPropertyName = "entr"
        Me.EntrDataGridViewCheckBoxColumn.HeaderText = "entr"
        Me.EntrDataGridViewCheckBoxColumn.Name = "EntrDataGridViewCheckBoxColumn"
        '
        'KmparcouruDataGridViewTextBoxColumn
        '
        Me.KmparcouruDataGridViewTextBoxColumn.DataPropertyName = "kmparcouru"
        Me.KmparcouruDataGridViewTextBoxColumn.HeaderText = "kmparcouru"
        Me.KmparcouruDataGridViewTextBoxColumn.Name = "KmparcouruDataGridViewTextBoxColumn"
        '
        'MontantentrDataGridViewTextBoxColumn
        '
        Me.MontantentrDataGridViewTextBoxColumn.DataPropertyName = "montantentr"
        Me.MontantentrDataGridViewTextBoxColumn.HeaderText = "montantentr"
        Me.MontantentrDataGridViewTextBoxColumn.Name = "MontantentrDataGridViewTextBoxColumn"
        '
        'MontantcbrtDataGridViewTextBoxColumn
        '
        Me.MontantcbrtDataGridViewTextBoxColumn.DataPropertyName = "montantcbrt"
        Me.MontantcbrtDataGridViewTextBoxColumn.HeaderText = "montantcbrt"
        Me.MontantcbrtDataGridViewTextBoxColumn.Name = "MontantcbrtDataGridViewTextBoxColumn"
        '
        'DepjrfcfaDataGridViewTextBoxColumn
        '
        Me.DepjrfcfaDataGridViewTextBoxColumn.DataPropertyName = "depjrfcfa"
        Me.DepjrfcfaDataGridViewTextBoxColumn.HeaderText = "depjrfcfa"
        Me.DepjrfcfaDataGridViewTextBoxColumn.Name = "DepjrfcfaDataGridViewTextBoxColumn"
        '
        'TsortieBindingSource1
        '
        Me.TsortieBindingSource1.DataMember = "Tsortie"
        Me.TsortieBindingSource1.DataSource = Me.BDGestParcBindingSource
        '
        'BDGestParcBindingSource
        '
        Me.BDGestParcBindingSource.DataSource = Me.BDGestParc
        Me.BDGestParcBindingSource.Position = 0
        '
        'BDGestParc
        '
        Me.BDGestParc.DataSetName = "BDGestParc"
        Me.BDGestParc.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DataGridViewVoitu)
        Me.GroupBox2.Controls.Add(Me.Combovoitu)
        Me.GroupBox2.ForeColor = System.Drawing.Color.DarkRed
        Me.GroupBox2.Location = New System.Drawing.Point(6, 14)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(625, 100)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Choisissez la voiture SVP"
        '
        'DataGridViewVoitu
        '
        Me.DataGridViewVoitu.AutoGenerateColumns = False
        Me.DataGridViewVoitu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewVoitu.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ImmvoituDataGridViewTextBoxColumn1, Me.MarqvoituDataGridViewTextBoxColumn, Me.Puissce100DataGridViewTextBoxColumn, Me.TypcbrtDataGridViewTextBoxColumn})
        Me.DataGridViewVoitu.DataSource = Me.TvoituBindingSource
        Me.DataGridViewVoitu.Location = New System.Drawing.Point(175, 13)
        Me.DataGridViewVoitu.Name = "DataGridViewVoitu"
        Me.DataGridViewVoitu.Size = New System.Drawing.Size(444, 81)
        Me.DataGridViewVoitu.TabIndex = 3
        '
        'ImmvoituDataGridViewTextBoxColumn1
        '
        Me.ImmvoituDataGridViewTextBoxColumn1.DataPropertyName = "immvoitu"
        Me.ImmvoituDataGridViewTextBoxColumn1.HeaderText = "immvoitu"
        Me.ImmvoituDataGridViewTextBoxColumn1.Name = "ImmvoituDataGridViewTextBoxColumn1"
        '
        'MarqvoituDataGridViewTextBoxColumn
        '
        Me.MarqvoituDataGridViewTextBoxColumn.DataPropertyName = "marqvoitu"
        Me.MarqvoituDataGridViewTextBoxColumn.HeaderText = "marqvoitu"
        Me.MarqvoituDataGridViewTextBoxColumn.Name = "MarqvoituDataGridViewTextBoxColumn"
        '
        'Puissce100DataGridViewTextBoxColumn
        '
        Me.Puissce100DataGridViewTextBoxColumn.DataPropertyName = "puissce100"
        Me.Puissce100DataGridViewTextBoxColumn.HeaderText = "puissce100"
        Me.Puissce100DataGridViewTextBoxColumn.Name = "Puissce100DataGridViewTextBoxColumn"
        '
        'TypcbrtDataGridViewTextBoxColumn
        '
        Me.TypcbrtDataGridViewTextBoxColumn.DataPropertyName = "typcbrt"
        Me.TypcbrtDataGridViewTextBoxColumn.HeaderText = "typcbrt"
        Me.TypcbrtDataGridViewTextBoxColumn.Name = "TypcbrtDataGridViewTextBoxColumn"
        '
        'TvoituBindingSource
        '
        Me.TvoituBindingSource.DataMember = "Tvoitu"
        Me.TvoituBindingSource.DataSource = Me.BDGestParcBindingSource
        '
        'Combovoitu
        '
        Me.Combovoitu.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Combovoitu.FormattingEnabled = True
        Me.Combovoitu.Location = New System.Drawing.Point(6, 36)
        Me.Combovoitu.Name = "Combovoitu"
        Me.Combovoitu.Size = New System.Drawing.Size(163, 22)
        Me.Combovoitu.TabIndex = 2
        Me.Combovoitu.Text = "Choix"
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(637, 398)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TsortieBindingSource
        '
        Me.TsortieBindingSource.DataMember = "Tsortie"
        Me.TsortieBindingSource.DataSource = Me.BDGestParc
        '
        'TsortieTableAdapter
        '
        Me.TsortieTableAdapter.ClearBeforeFill = True
        '
        'TvoituTableAdapter
        '
        Me.TvoituTableAdapter.ClearBeforeFill = True
        '
        'consulttsorti
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Chocolate
        Me.ClientSize = New System.Drawing.Size(904, 520)
        Me.Controls.Add(Me.Tabconsul)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.BindingNavigator1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "consulttsorti"
        Me.Text = "consulttsorti"
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.Tabconsul.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.DataGridViewSorti, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TsortieBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BDGestParcBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BDGestParc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DataGridViewVoitu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TvoituBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TsortieBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BindingNavigator1 As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents Button2 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ConsultationsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LesSortiesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents GestionDesAjoutsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AjouterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConducteurToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MotifToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VoitureToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TypeDentretienToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NouvelleSortieToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Tabconsul As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DataGridViewSorti As DataGridView
    Friend WithEvents BDGestParc As BDGestParc
    Friend WithEvents TsortieBindingSource As BindingSource
    Friend WithEvents TsortieTableAdapter As BDGestParcTableAdapters.TsortieTableAdapter
    Friend WithEvents BDGestParcBindingSource As BindingSource
    Friend WithEvents Combovoitu As ComboBox
    Friend WithEvents NumsortieDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DatsortieDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ImmvoituDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LibmotifDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NoconducDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents KmdepartDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents KmarriveDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CbrtDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents EntrDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents KmparcouruDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MontantentrDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MontantcbrtDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DepjrfcfaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TsortieBindingSource1 As BindingSource
    Friend WithEvents DataGridViewVoitu As DataGridView
    Friend WithEvents TvoituBindingSource As BindingSource
    Friend WithEvents TvoituTableAdapter As BDGestParcTableAdapters.TvoituTableAdapter
    Friend WithEvents ImmvoituDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents MarqvoituDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Puissce100DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TypcbrtDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
