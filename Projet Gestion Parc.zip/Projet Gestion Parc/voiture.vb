﻿Public Class voiture
    Private Sub ConducteurToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConducteurToolStripMenuItem.Click
        conducteur.Show()
    End Sub

    Private Sub MotifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotifToolStripMenuItem.Click
        motif.Show()
    End Sub

    Private Sub TypeDentretienToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TypeDentretienToolStripMenuItem.Click
        typentretien.Show()
    End Sub

    Private Sub LesSortiesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LesSortiesToolStripMenuItem.Click

    End Sub

    Private Sub CmdAnnuler_Click(sender As Object, e As EventArgs) Handles CmdAnnuler.Click
        CmdEnregistrer.Enabled = True
        CmdNvo.Enabled = True
    End Sub

    Private Sub CmdNvo_Click(sender As Object, e As EventArgs) Handles CmdNvo.Click
        On Error GoTo Gesterr
        Dim strcode As String
        Dim Taille As String

        If L.RecordCount = 0 Then
            strcode = "CL" & CStr(Year(DateTime.Today)) & CStr(-1)
            Textimm.Text = strcode
            Textmarq.Focus()

        Else
            L.MoveLast()
            Taille = Mid(L(0).Value, 8, CInt(Len(L(0).Value) - CInt(Len(Mid(L(0).Value, 1, 7)))))
            strcode = "CL" & CStr(Year(DateTime.Today)) & -CStr(CInt(Taille) + 1)
            Textimm.Text = strcode
            Textmarq.Focus()

        End If

        CmdEnregistrer.Enabled = False
        CmdAnnuler.Enabled = False

        'Textimm.Text = ""
        Textimm.Text = ""
        Textmarq.Text = ""

        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub CmdEnregistrer_Click(sender As Object, e As EventArgs) Handles CmdEnregistrer.Click
        On Error GoTo Gesterr

        If Textimm.Text = "" Then
            MsgBox("Saisissez l'immatriculation de la voiture", vbInformation, "Vérification")
            Textimm.Focus()
            Exit Sub
        End If

        If Textmarq.Text = "" Then
            MsgBox("Saisissez la marque", vbInformation, "Vérification")
            Textmarq.Focus()
            Exit Sub
        End If

        If Textpuissce.Text = "" Then
            MsgBox("Entrez la puissance au 100 km", vbInformation, "Vérification")
            Textpuissce.Focus()
            Exit Sub
        End If

        If Texttypcbrt.Text = "" Then
            MsgBox("Saisissez le type de carburant", vbInformation, "Vérification")
            Texttypcbrt.Focus()
            Exit Sub
        End If

        Do While Not L.EOF
            If L(0).Value = Textimm.Text Then
                MsgBox("L'enregistrement existe déjà", MsgBoxStyle.Critical, "Vérification de données")
                Exit Sub
            Else
                reponse = MsgBox("Voulez-vous enregistrer les données?", MsgBoxStyle.YesNo, "Stockage de données")
                If reponse = vbYes Then
                    L.AddNew()
                    L(0).Value = Textimm.Text
                    L(1).Value = Textmarq.Text
                    L(2).Value = Textpuissce.Text
                    L(3).Value = Texttypcbrt.Text

                    L.Update()


                    MsgBox("Ajout de données réussi!", MsgBoxStyle.Information, "Enregistrement")
                    CmdNvo_Click(CmdNvo, e)
                    Exit Sub
                Else
                    Exit Sub
                End If
                L.MoveNext()
            End If
        Loop
        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub NouvelleSortieToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NouvelleSortieToolStripMenuItem.Click
        nouvellesortie.Show()
    End Sub
End Class