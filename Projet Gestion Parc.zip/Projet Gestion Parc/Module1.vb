﻿Module Module1
    Public Structure UTILISATEUR
        Public Nom As String
        Public Pwd As String
    End Structure


    Public util As UTILISATEUR
    Public canal As Integer
    Public position
    Public L As New ADODB.Recordset
    Public db As New ADODB.Connection
    Public Larequete As String
    Public i, j, reponse As Integer
    Public reference
    Public photoname As String
    Public trouve As Boolean
    Public chemin As String

    Public Sub Connecter()
        'racine = Application.StartupPath + "\\FasylBD.accdb\\"
        db.Provider = "Microsoft.ACE.OLEDB.12.0"
        db.Open("C:\ProjBDGestParc\BDGestParc.accdb")
    End Sub
End Module
