﻿Public Class nouvellesortie
    Private Sub ConducteurToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConducteurToolStripMenuItem.Click
        conducteur.Show()
    End Sub

    Private Sub MotifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotifToolStripMenuItem.Click
        motif.Show()
    End Sub

    Private Sub VoitureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VoitureToolStripMenuItem.Click
        voiture.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub LesSortiesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LesSortiesToolStripMenuItem.Click
        consulttsorti.Show()
    End Sub

    Private Sub TypeDentretienToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TypeDentretienToolStripMenuItem.Click
        typentretien.Show()
    End Sub


    Private Sub CmdAnnuler_Click(sender As Object, e As EventArgs) Handles CmdAnnuler.Click
        On Error GoTo Gesterr
        If L.RecordCount = 0 Then
            CmdEnregistrer.Enabled = True
            CmdNvo.Enabled = True

        Else

            CmdEnregistrer.Enabled = True
            CmdNvo.Enabled = True

        End If

        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub CmdNvo_Click(sender As Object, e As EventArgs) Handles CmdNvo.Click
        If L.RecordCount = 0 Then
            Textnumenrg.Text = "Enregistrement N°: " & 1 & "/" & 1
        Else
            L.MoveLast()
            Textnumenrg.Text = "Enregistrement N°: " & CStr(CInt(L.RecordCount) + 1) & "/" & CStr(CInt(L.RecordCount) + 1)
        End If

        CmdAnnuler.Enabled = False
        CmdEnregistrer.Enabled = False

        Textdat.Text = ""
        Combovoitu.Text = ""
        Combomotif.Text = ""
        Comboconduc.Text = ""
        Textkmdep.Text = ""
        Textkmarr.Text = ""
        Combovoitu.Focus()
    End Sub

    Private Sub CmdEnregistrer_Click(sender As Object, e As EventArgs) Handles CmdEnregistrer.Click
        Dim p1 As Integer
        Dim p2 As String
        Dim p3 As String
        p1 = vbNull
        p2 = ""
        p3 = ""

        p1 = CInt(InStr(1, Combovoitu.Text, " "))
        p2 = InStr(1, Combomotif.Text, " ")
        p3 = InStr(2, Comboconduc.Text, " ")

        If p1 > 0 Then
            Combovoitu.Text = Mid(Combovoitu.Text, 1, (CInt(p1) - 1))
        End If

        If p2 > 0 Then
            Combomotif.Text = Mid(Combomotif.Text, 1, (CInt(p2) - 1))
        End If

        If p3 > 0 Then
            Comboconduc.Text = Mid(Comboconduc.Text, 1, (CInt(p2) - 1))
        End If

        If Combovoitu.Text = "" Then
            MsgBox("Choisissez le numéro de la voiture", vbInformation)
            Combovoitu.Focus()
            Exit Sub
        End If

        If Combomotif.Text = "" Then
            MsgBox("Choisissez le numéro du motif", vbInformation)
            Combomotif.Focus()
            Exit Sub
        End If

        If Comboconduc.Text = "" Then
            MsgBox("Choisissez le numéro du conducteur", vbInformation)
            Comboconduc.Focus()
            Exit Sub
        End If

        If Textdat.Text = "" Then
            MsgBox("Saisissez la date de la sortie", vbInformation)
            Textdat.Focus()
            Exit Sub
        End If

        If Textkmdep.Text = "" Then
            MsgBox("Saisissez le km de depart", vbInformation)
            Textkmdep.Focus()
            Exit Sub
        End If

        If Textkmarr.Text = "" Then
            MsgBox("Saisissez le km d'arrivee", vbInformation)
            Textkmarr.Focus()
            Exit Sub
        End If

        If Not IsNumeric(Textnumenrg.Text) Then
            MsgBox("Le nombre saisi doit être numérique", vbInformation)
            Textnumenrg.Focus()
            Exit Sub
        End If

        Do While Not L.EOF
            reponse = MsgBox("Voulez-vous enregistrer les données?", MsgBoxStyle.YesNo, "Stockage de données")
            If reponse = vbYes Then
                L.AddNew()
                L(0).Value = Textnumenrg.Text
                L(1).Value = Textdat.Text
                L(2).Value = Combovoitu.Text
                L(3).Value = Combomotif.Text
                L(4).Value = Comboconduc.Text
                L(5).Value = Textkmdep.Text
                L(6).Value = Textkmarr.Text
                L(7).Value = Checkcbrt.Checked
                L(9).Value = Checkentr.Checked
                L.Update()
                MsgBox("Ajout de données réussi!", MsgBoxStyle.Information, "Enregistrement")
                CmdNvo_Click(CmdNvo, e)
                Exit Sub
            Else
                Exit Sub
            End If
            L.MoveNext()
        Loop
    End Sub

    Private Sub Checkcbrt_CheckedChanged(sender As Object, e As EventArgs) Handles Checkcbrt.CheckedChanged
        If Checkcbrt.Checked = True Then
            carburant.Show()
        End If
    End Sub

    Private Sub Checkentr_CheckedChanged(sender As Object, e As EventArgs) Handles Checkentr.CheckedChanged
        If Checkentr.Checked = True Then
            Entretien.Show()
        End If
    End Sub
End Class