﻿Public Class typentretien
    Private Sub ConducteurToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConducteurToolStripMenuItem.Click
        conducteur.Show()
    End Sub

    Private Sub MotifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotifToolStripMenuItem.Click
        motif.Show()
    End Sub

    Private Sub VoitureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VoitureToolStripMenuItem.Click
        voiture.Show()
    End Sub

    Private Sub LesSortiesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LesSortiesToolStripMenuItem.Click
        consulttsorti.Show()
    End Sub

    Private Sub CmdAnnuler_Click(sender As Object, e As EventArgs) Handles CmdAnnuler.Click
        CmdEnregistrer.Enabled = True
        CmdNvo.Enabled = True
    End Sub

    Private Sub CmdNvo_Click(sender As Object, e As EventArgs) Handles CmdNvo.Click
        Dim strcode As String
        Dim Taille As String

        If L.RecordCount = 0 Then
            strcode = "CL" & CStr(Year(DateTime.Today)) & CStr(-1)
            Textlibentr.Text = strcode

        Else
            L.MoveLast()
            Taille = Mid(L(0).Value, 8, CInt(Len(L(0).Value) - CInt(Len(Mid(L(0).Value, 1, 7)))))
            strcode = "CL" & CStr(Year(DateTime.Today)) & -CStr(CInt(Taille) + 1)
            Textlibentr.Text = strcode

        End If

        CmdEnregistrer.Enabled = False
        CmdAnnuler.Enabled = False

        'Textlibentr.Text = ""
        Textlibentr.Text = ""


        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub CmdEnregistrer_Click(sender As Object, e As EventArgs) Handles CmdEnregistrer.Click
        If Textlibentr.Text = "" Then
            MsgBox("Saisissez le nom et prénoms", vbInformation, "Vérification")
            Textlibentr.Focus()
            Exit Sub
        End If
    End Sub

    Private Sub NouvelleSortieToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NouvelleSortieToolStripMenuItem.Click
        nouvellesortie.Show()
    End Sub
End Class