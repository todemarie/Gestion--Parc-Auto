﻿Public Class consulttsorti
    Private Sub ConducteurToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConducteurToolStripMenuItem.Click
        conducteur.Show()
    End Sub

    Private Sub MotifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotifToolStripMenuItem.Click
        motif.Show()
    End Sub

    Private Sub VoitureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VoitureToolStripMenuItem.Click
        voiture.Show()
    End Sub

    Private Sub TypeDentretienToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TypeDentretienToolStripMenuItem.Click
        typentretien.Show()
    End Sub

    Private Sub NouvelleSortieToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NouvelleSortieToolStripMenuItem.Click
        nouvellesortie.Show()
    End Sub



    Private Sub Combovoitu_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combovoitu.SelectedIndexChanged
        Dim T As New ADODB.Recordset

        T.ActiveConnection = db
        T.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        Larequete = "Select * From Tsortie WHERE Tsortie.numsortie = '" & Combovoitu.Text & "'"
        T.Open(Larequete, , ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)

        i = 0
        Do While Not T.EOF
            i = i + 1
            T.MoveNext()
        Loop
        T.Requery()
        DataGridViewVoitu.Rows.Clear()
        DataGridViewVoitu.Rows.Add(i)
        If DataGridViewVoitu.Text = "" Then
            DataGridViewVoitu.Rows.Add(1)
            Exit Sub
        End If
        j = 0
        While Not T.EOF And j < i
            DataGridViewSorti.Rows(j).Cells(0).Value = T(0).Value
            DataGridViewSorti.Rows(j).Cells(1).Value = T(1).Value
            DataGridViewSorti.Rows(j).Cells(2).Value = T(2).Value
            DataGridViewSorti.Rows(j).Cells(3).Value = T(3).Value
            DataGridViewSorti.Rows(j).Cells(4).Value = T(4).Value
            DataGridViewSorti.Rows(j).Cells(5).Value = T(5).Value
            DataGridViewSorti.Rows(j).Cells(6).Value = T(6).Value
            DataGridViewSorti.Rows(j).Cells(7).Value = T(7).Value
            DataGridViewSorti.Rows(j).Cells(8).Value = T(8).Value
            DataGridViewSorti.Rows(j).Cells(9).Value = T(9).Value
            DataGridViewSorti.Rows(j).Cells(10).Value = T(10).Value
            DataGridViewSorti.Rows(j).Cells(11).Value = T(11).Value
            DataGridViewSorti.Rows(j).Cells(12).Value = T(12).Value

            j = j + 1
            T.MoveNext()
        End While
        T.Close()
    End Sub

    Private Sub consulttsorti_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Rs As New ADODB.Recordset

        'Connecter()


    End Sub
End Class