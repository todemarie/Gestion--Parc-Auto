﻿Public Class Connexion
    Private Sub CmdNcpte_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles CmdNcpte.LinkClicked
        Nouvocpte.Show()
        Me.Close()
    End Sub

    Private Sub Cmdok_Click(sender As Object, e As EventArgs) Handles Cmdok.Click
        Dim j, trouve
        Dim cpte As Integer

        canal = FreeFile()
        If TextUsername.Text = "" Then
            MsgBox("Vous devez saisir un nom utilisteur valide, réessayez !", vbExclamation, "Connexion")
            TextUsername.Focus()
            Exit Sub
        End If
        If TextPassword.Text = "" Then
            MsgBox("Vous devez saisir un mot de passe valide, réessayez !", vbExclamation, "Connexion")
            TextPassword.Focus()
            Exit Sub
        End If

        FileOpen(canal, "C:\ProjBDGestParc\user.dat", OpenMode.Random)
        trouve = False
        j = 1
        Do While Not EOF(canal)
            FileGet(canal, util, j)
            'MsgBox("result = " & util.Nom & "    " & util.Pwd)
            'Exit Sub

            j = j + 1
            cpte = cpte + 1
        Loop

        If trouve = False Then
            MsgBox("Mot de passe et ou nom utilisateur non valide, réessayez !", vbExclamation, "Connexion")
            TextUsername.Focus()
            'SendKeys "{Home}+{End}"
        End If
        FileClose(canal)
    End Sub

    Private Sub TextPassword_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextUsername.KeyDown, TextPassword.KeyDown
        If e.KeyCode = Keys.Enter Then
            Cmdok_Click(Cmdok, e)
        End If
    End Sub


    Private Sub TextPassword_TextChanged(sender As Object, e As EventArgs) Handles TextPassword.TextChanged

    End Sub
End Class
