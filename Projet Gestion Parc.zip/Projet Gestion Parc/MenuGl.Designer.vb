﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuGl
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ConsultationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LesSortiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.GestionDesAjoutsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AjouterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConducteurToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MotifToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoitureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NouvelleSotieToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Coral
        Me.Button1.Location = New System.Drawing.Point(843, 1)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(26, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "X"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel1.Location = New System.Drawing.Point(248, 47)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(291, 10)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel2.Location = New System.Drawing.Point(248, 215)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(291, 10)
        Me.Panel2.TabIndex = 2
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ProjBDGestParc.My.Resources.Resources.conduct
        Me.PictureBox1.Location = New System.Drawing.Point(276, 83)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(96, 95)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.MenuStrip1)
        Me.GroupBox1.Controls.Add(Me.MenuStrip2)
        Me.GroupBox1.Location = New System.Drawing.Point(25, 92)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(229, 75)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Menu Général"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConsultationsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(3, 40)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(223, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ConsultationsToolStripMenuItem
        '
        Me.ConsultationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LesSortiesToolStripMenuItem})
        Me.ConsultationsToolStripMenuItem.Name = "ConsultationsToolStripMenuItem"
        Me.ConsultationsToolStripMenuItem.Size = New System.Drawing.Size(92, 20)
        Me.ConsultationsToolStripMenuItem.Text = "Consultations"
        '
        'LesSortiesToolStripMenuItem
        '
        Me.LesSortiesToolStripMenuItem.Name = "LesSortiesToolStripMenuItem"
        Me.LesSortiesToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.LesSortiesToolStripMenuItem.Text = "les sorties"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GestionDesAjoutsToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(3, 16)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(223, 24)
        Me.MenuStrip2.TabIndex = 1
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'GestionDesAjoutsToolStripMenuItem
        '
        Me.GestionDesAjoutsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AjouterToolStripMenuItem})
        Me.GestionDesAjoutsToolStripMenuItem.Name = "GestionDesAjoutsToolStripMenuItem"
        Me.GestionDesAjoutsToolStripMenuItem.Size = New System.Drawing.Size(115, 20)
        Me.GestionDesAjoutsToolStripMenuItem.Text = "Gestion des ajouts"
        '
        'AjouterToolStripMenuItem
        '
        Me.AjouterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConducteurToolStripMenuItem, Me.MotifToolStripMenuItem, Me.VoitureToolStripMenuItem, Me.NouvelleSotieToolStripMenuItem})
        Me.AjouterToolStripMenuItem.Name = "AjouterToolStripMenuItem"
        Me.AjouterToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AjouterToolStripMenuItem.Text = "Ajouter"
        '
        'ConducteurToolStripMenuItem
        '
        Me.ConducteurToolStripMenuItem.Name = "ConducteurToolStripMenuItem"
        Me.ConducteurToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ConducteurToolStripMenuItem.Text = "conducteur"
        '
        'MotifToolStripMenuItem
        '
        Me.MotifToolStripMenuItem.Name = "MotifToolStripMenuItem"
        Me.MotifToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.MotifToolStripMenuItem.Text = "motif"
        '
        'VoitureToolStripMenuItem
        '
        Me.VoitureToolStripMenuItem.Name = "VoitureToolStripMenuItem"
        Me.VoitureToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.VoitureToolStripMenuItem.Text = "voiture"
        '
        'NouvelleSotieToolStripMenuItem
        '
        Me.NouvelleSotieToolStripMenuItem.Name = "NouvelleSotieToolStripMenuItem"
        Me.NouvelleSotieToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.NouvelleSotieToolStripMenuItem.Text = "nouvelle sotie"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Gold
        Me.LinkLabel1.Location = New System.Drawing.Point(378, 120)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(154, 23)
        Me.LinkLabel1.TabIndex = 8
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Nouvelle sortie"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Tomato
        Me.Button2.Location = New System.Drawing.Point(566, -1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(27, 23)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "X"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'MenuGl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(593, 267)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MenuGl"
        Me.Text = "MenuGl"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents ConsultationsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GestionDesAjoutsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AjouterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConducteurToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MotifToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VoitureToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LesSortiesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Button2 As Button
    Friend WithEvents NouvelleSotieToolStripMenuItem As ToolStripMenuItem
End Class
