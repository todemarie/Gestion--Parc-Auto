﻿Public Class conducteur


    Private Sub MotifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotifToolStripMenuItem.Click
        motif.Show()
    End Sub

    Private Sub VoitureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VoitureToolStripMenuItem.Click
        voiture.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub TypeDentretienToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TypeDentretienToolStripMenuItem.Click
        typentretien.Show()
    End Sub

    Private Sub LesSortiesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LesSortiesToolStripMenuItem.Click
        consulttsorti.Show()
    End Sub

    Private Sub CmdAnnuler_Click(sender As Object, e As EventArgs) Handles CmdAnnuler.Click
        CmdEnregistrer.Enabled = True
        CmdNvo.Enabled = True

    End Sub

    Private Sub CmdNvo_Click(sender As Object, e As EventArgs) Handles CmdNvo.Click
        On Error GoTo Gesterr
        Dim strcode As String
        Dim Taille As String

        If L.RecordCount = 0 Then
            strcode = "CL" & CStr(Year(DateTime.Today)) & CStr(-1)
            Textnom.Text = strcode
            Textpren.Focus()

        Else
            L.MoveLast()
            Taille = Mid(L(0).Value, 8, CInt(Len(L(0).Value) - CInt(Len(Mid(L(0).Value, 1, 7)))))
            strcode = "CL" & CStr(Year(DateTime.Today)) & -CStr(CInt(Taille) + 1)
            Textnom.Text = strcode
            Textpren.Focus()

        End If

        CmdEnregistrer.Enabled = False
        CmdAnnuler.Enabled = False

        'Textnom.Text = ""
        Textnom.Text = ""
        Textpren.Text = ""

        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub CmdEnregistrer_Click(sender As Object, e As EventArgs) Handles CmdEnregistrer.Click
        On Error GoTo Gesterr

        If Textnom.Text = "" Then
            MsgBox("Saisissez le nom du conducteur", vbInformation, "Vérification")
            Textnom.Focus()
            Exit Sub
        End If

        If Textpren.Text = "" Then
            MsgBox("Saisissez le prénom du conducteur", vbInformation, "Vérification")
            Textpren.Focus()
            Exit Sub
        End If

        If Texttel.Text = "" Then
            MsgBox("Choisissez le tel du conducteur", vbInformation, "Vérification")
            Texttel.Focus()
            Exit Sub
        End If


        Do While Not L.EOF
            If L(0).Value = Textnom.Text Then
                MsgBox("L'enregistrement existe déjà", MsgBoxStyle.Critical, "Vérification de données")
                Exit Sub
            Else
                reponse = MsgBox("Voulez-vous enregistrer les données?", MsgBoxStyle.YesNo, "Stockage de données")
                If reponse = vbYes Then
                    L.AddNew()
                    L(0).Value = Textnom.Text
                    L(1).Value = Textpren.Text
                    L(2).Value = Texttel.Text


                    L.Update()


                    MsgBox("Ajout de données réussi!", MsgBoxStyle.Information, "Enregistrement")
                    CmdNvo_Click(CmdNvo, e)
                    Exit Sub
                Else
                    Exit Sub
                End If
                L.MoveNext()
            End If
        Loop
        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub Textnom_TextChanged(sender As Object, e As EventArgs) Handles Textnom.TextChanged
        Textnom.CharacterCasing = CharacterCasing.Upper
    End Sub

    Private Sub Textpren_TextChanged(sender As Object, e As EventArgs) Handles Textpren.TextChanged
        Textpren.CharacterCasing = CharacterCasing.Upper
    End Sub

    Private Sub conducteur_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error GoTo Gesterr
        'Connecter()
        L.ActiveConnection = db

        Larequete = "Select * From Tconduc ORDER BY Tconduc.noconduc"
        L.Open(Larequete, , ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)



        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub Texttel_TextChanged(sender As Object, e As EventArgs) Handles Texttel.TextChanged
        Texttel.CharacterCasing = CharacterCasing.Upper
    End Sub

    Private Sub NouvelleSortieToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NouvelleSortieToolStripMenuItem.Click
        nouvellesortie.Show()
    End Sub
End Class