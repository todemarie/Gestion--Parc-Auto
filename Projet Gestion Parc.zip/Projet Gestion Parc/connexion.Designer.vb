﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Connexion
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Cmdok = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextPassword = New System.Windows.Forms.TextBox()
        Me.TextUsername = New System.Windows.Forms.TextBox()
        Me.CmdNcpte = New System.Windows.Forms.LinkLabel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Cmdok)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.TextPassword)
        Me.Panel1.Controls.Add(Me.TextUsername)
        Me.Panel1.Location = New System.Drawing.Point(12, 44)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(282, 197)
        Me.Panel1.TabIndex = 1
        '
        'Cmdok
        '
        Me.Cmdok.BackColor = System.Drawing.Color.OliveDrab
        Me.Cmdok.Location = New System.Drawing.Point(105, 156)
        Me.Cmdok.Name = "Cmdok"
        Me.Cmdok.Size = New System.Drawing.Size(45, 23)
        Me.Cmdok.TabIndex = 4
        Me.Cmdok.Text = "Ok"
        Me.Cmdok.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel3.Location = New System.Drawing.Point(35, 119)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(200, 10)
        Me.Panel3.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel2.Location = New System.Drawing.Point(35, 55)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(200, 10)
        Me.Panel2.TabIndex = 1
        '
        'TextPassword
        '
        Me.TextPassword.BackColor = System.Drawing.SystemColors.Control
        Me.TextPassword.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextPassword.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextPassword.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextPassword.ForeColor = System.Drawing.Color.Gray
        Me.TextPassword.Location = New System.Drawing.Point(37, 93)
        Me.TextPassword.Name = "TextPassword"
        Me.TextPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextPassword.Size = New System.Drawing.Size(198, 24)
        Me.TextPassword.TabIndex = 2
        Me.TextPassword.Text = "Mot de passe"
        Me.TextPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextPassword.UseSystemPasswordChar = True
        '
        'TextUsername
        '
        Me.TextUsername.BackColor = System.Drawing.SystemColors.Control
        Me.TextUsername.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextUsername.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextUsername.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextUsername.ForeColor = System.Drawing.Color.Gray
        Me.TextUsername.Location = New System.Drawing.Point(37, 29)
        Me.TextUsername.Name = "TextUsername"
        Me.TextUsername.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextUsername.Size = New System.Drawing.Size(198, 24)
        Me.TextUsername.TabIndex = 0
        Me.TextUsername.Text = "Utilisateur"
        Me.TextUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CmdNcpte
        '
        Me.CmdNcpte.AutoSize = True
        Me.CmdNcpte.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdNcpte.Location = New System.Drawing.Point(96, 244)
        Me.CmdNcpte.Name = "CmdNcpte"
        Me.CmdNcpte.Size = New System.Drawing.Size(100, 15)
        Me.CmdNcpte.TabIndex = 5
        Me.CmdNcpte.TabStop = True
        Me.CmdNcpte.Text = "Nouveau compte"
        '
        'connexion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(306, 274)
        Me.Controls.Add(Me.CmdNcpte)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "connexion"
        Me.Text = "Connexion"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextUsername As TextBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextPassword As TextBox
    Friend WithEvents Cmdok As Button
    Friend WithEvents CmdNcpte As LinkLabel
End Class
