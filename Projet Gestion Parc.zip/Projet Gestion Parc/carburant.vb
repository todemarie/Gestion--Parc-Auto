﻿Public Class carburant
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub ConducteurToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConducteurToolStripMenuItem.Click
        conducteur.Show()
    End Sub

    Private Sub MotifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotifToolStripMenuItem.Click
        motif.Show()
    End Sub

    Private Sub VoitureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VoitureToolStripMenuItem.Click
        voiture.Show()
    End Sub

    Private Sub LesSortiesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LesSortiesToolStripMenuItem.Click
        consulttsorti.Show()
    End Sub

    Private Sub TypeDEntretienToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TypeDEntretienToolStripMenuItem.Click
        typentretien.Show()
    End Sub

    Private Sub CmdAnnuler_Click(sender As Object, e As EventArgs) Handles CmdAnnuler.Click
        If L.RecordCount = 0 Then
            CmdEnregistrer.Enabled = True
            CmdNvo.Enabled = True


        Else

            CmdNvo.Enabled = True
            CmdEnregistrer.Enabled = True

        End If

        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub CmdNvo_Click(sender As Object, e As EventArgs) Handles CmdNvo.Click
        On Error GoTo Gesterr
        Dim strcode As String
        Dim Taille As String

        If L.RecordCount = 0 Then
            strcode = CStr(1)
            Textprixun.Text = strcode
            Textqte.Focus()

            L.MoveLast()
            strcode = L(0).Value + 1
            Textprixun.Text = strcode
            Textqte.Focus()

        End If

        CmdAnnuler.Enabled = False
        CmdEnregistrer.Enabled = False


        Textdat.Text = DateTime.Today
        Textprixun.Text = ""
        Textdat.Text = ""
        Textprixun.Text = ""
        Textmontcbrt.Text = ""


        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub CmdEnregistrer_Click(sender As Object, e As EventArgs) Handles CmdEnregistrer.Click
        Dim p1 As Integer
        Dim p2 As String


        If Textprixun.Text = "" Then
            MsgBox("Saisissez le prix du carburant", vbInformation, "Vérification")
            Textprixun.Focus()
            Exit Sub
        End If

        If Textqte.Text = "" Then
            MsgBox("Saisissez la quantité achetée", vbInformation, "Vérification")
            Textqte.Focus()
            Exit Sub
        End If

        If Textmontcbrt.Text = "" Then
            MsgBox("Saisissez le montant ", vbInformation, "Vérification")
            Textmontcbrt.Focus()
            Exit Sub
        End If





        reponse = MsgBox("Voulez-vous enregistrer les données?", MsgBoxStyle.YesNo, "Stockage de données")
                If reponse = vbYes Then
                    L.AddNew()
            L(0).Value = Textqte.Text
            L(1).Value = Textmontcbrt.Text
            L(2).Value = p2.ToString
            L.Update()
                    MsgBox("Ajout de données réussi!", MsgBoxStyle.Information, "Enregistrement")
                CmdNvo_Click(CmdNvo, e)
                Exit Sub
                Else
                    Exit Sub
                End If
                L.MoveNext()


    End Sub

    Private Sub carburant_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error GoTo Gesterr
        'Connecter()
        L.ActiveConnection = db
        L.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        Larequete = "Select * From Tcbrt"
        L.Open(Larequete, , ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)

        If L.RecordCount > 0 Then


            Textprixun.Text = ""
            Textqte.Text = ""
            Textmontcbrt.Text = ""

            Textdat.Text = DateTime.Today

        End If



        Exit Sub

Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub NouvelleSortieToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NouvelleSortieToolStripMenuItem.Click
        nouvellesortie.Show()
    End Sub
End Class