﻿Public Class Nouvocpte
    Private Sub Cmdok_Click(sender As Object, e As EventArgs) Handles Cmdok.Click
        util.Nom = Textutlst.Text
        util.Pwd = Textmdp.Text
        util.Pwd = Textmdpconf.Text

        If Textutlst.Text = "" And Textmdp.Text = "" And Textmdpconf.Text = "" Then
            MsgBox("Saisissez un nom utilisateur et un mot de passe puis la confirmation", vbExclamation, "Création de compte")
            Textutlst.Focus()
            Exit Sub
        End If
        If Textmdp.Text <> Textmdpconf.Text Then
            MsgBox("Mot de passe de confirmation différent", vbExclamation, "Création de compte")
            Textmdpconf.Focus()
        Else
            i = LOF(canal) / Len(util)
            FilePut(canal, util, i + 1)
            MsgBox("Ajout de compte reussi!", vbInformation, "Création de compte")
            FileClose(canal)
            connexion.Show()
            connexion.TextUsername.Focus()
            Me.Close()
        End If
    End Sub

    Private Sub txtnomutil_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Textutlst.KeyDown
        If e.KeyCode = Keys.Enter Then
            Textmdp.Focus()
        End If
    End Sub

    Private Sub txtnomutil_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Textutlst.TextChanged

    End Sub

    Private Sub txtmotpass_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Textmdp.KeyDown
        If e.KeyCode = Keys.Enter Then
            Textmdpconf.Focus()
        End If
    End Sub

    Private Sub txtconfirmer_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Textmdpconf.KeyDown
        If e.KeyCode = Keys.Enter Then
            Cmdok_Click(Cmdok, e)
        End If
    End Sub

    Private Sub txtmotpass_TextChanged(sender As Object, e As EventArgs) Handles Textmdp.TextChanged
        If Textmdp.TextLength > 8 Then
            MsgBox("Le mot de passe doit contenir au maximum 8 caractères")
            Textmdp.Text = ""
            Textmdp.Focus()
        End If
    End Sub

    Private Sub Nouvocpte_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim n

        canal = FreeFile()

        FileOpen(canal, "C:\ProjetGesatelier\user.dat", OpenMode.Random)
        i = 0
        n = LOF(canal) / Len(util)
        If n = 0 Then
            MsgBox("fichier vide")
        Else
            i = 1
            FileGet(canal, util, i)
        End If
    End Sub
End Class