﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Nouvocpte
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Textmdpconf = New System.Windows.Forms.TextBox()
        Me.Cmdok = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Textmdp = New System.Windows.Forms.TextBox()
        Me.Textutlst = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Textmdpconf)
        Me.Panel1.Controls.Add(Me.Cmdok)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Textmdp)
        Me.Panel1.Controls.Add(Me.Textutlst)
        Me.Panel1.Location = New System.Drawing.Point(12, 38)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(282, 274)
        Me.Panel1.TabIndex = 2
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel4.Location = New System.Drawing.Point(35, 186)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(200, 10)
        Me.Panel4.TabIndex = 5
        '
        'Textmdpconf
        '
        Me.Textmdpconf.BackColor = System.Drawing.SystemColors.Control
        Me.Textmdpconf.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Textmdpconf.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Textmdpconf.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textmdpconf.ForeColor = System.Drawing.Color.Gray
        Me.Textmdpconf.Location = New System.Drawing.Point(37, 160)
        Me.Textmdpconf.Name = "Textmdpconf"
        Me.Textmdpconf.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Textmdpconf.Size = New System.Drawing.Size(198, 24)
        Me.Textmdpconf.TabIndex = 4
        Me.Textmdpconf.Text = "Mot de passe"
        Me.Textmdpconf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Textmdpconf.UseSystemPasswordChar = True
        '
        'Cmdok
        '
        Me.Cmdok.BackColor = System.Drawing.Color.OliveDrab
        Me.Cmdok.Location = New System.Drawing.Point(108, 229)
        Me.Cmdok.Name = "Cmdok"
        Me.Cmdok.Size = New System.Drawing.Size(45, 23)
        Me.Cmdok.TabIndex = 4
        Me.Cmdok.Text = "Ok"
        Me.Cmdok.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel3.Location = New System.Drawing.Point(35, 119)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(200, 10)
        Me.Panel3.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel2.Location = New System.Drawing.Point(35, 55)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(200, 10)
        Me.Panel2.TabIndex = 1
        '
        'Textmdp
        '
        Me.Textmdp.BackColor = System.Drawing.SystemColors.Control
        Me.Textmdp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Textmdp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Textmdp.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textmdp.ForeColor = System.Drawing.Color.Gray
        Me.Textmdp.Location = New System.Drawing.Point(37, 93)
        Me.Textmdp.Name = "Textmdp"
        Me.Textmdp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Textmdp.Size = New System.Drawing.Size(198, 24)
        Me.Textmdp.TabIndex = 2
        Me.Textmdp.Text = "Mot de passe"
        Me.Textmdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Textmdp.UseSystemPasswordChar = True
        '
        'Textutlst
        '
        Me.Textutlst.BackColor = System.Drawing.SystemColors.Control
        Me.Textutlst.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Textutlst.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Textutlst.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textutlst.ForeColor = System.Drawing.Color.Gray
        Me.Textutlst.Location = New System.Drawing.Point(37, 29)
        Me.Textutlst.Name = "Textutlst"
        Me.Textutlst.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Textutlst.Size = New System.Drawing.Size(198, 24)
        Me.Textutlst.TabIndex = 0
        Me.Textutlst.Text = "Utilisateur"
        Me.Textutlst.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Nouvocpte
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(305, 322)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Name = "Nouvocpte"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Nouveau compte"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Textmdpconf As TextBox
    Friend WithEvents Cmdok As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Textmdp As TextBox
    Friend WithEvents Textutlst As TextBox
End Class
