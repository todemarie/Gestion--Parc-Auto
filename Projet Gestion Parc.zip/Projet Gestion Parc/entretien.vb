﻿Public Class Entretien
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub ConducteurToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConducteurToolStripMenuItem.Click
        conducteur.Show()
    End Sub

    Private Sub MotifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotifToolStripMenuItem.Click
        motif.Show()
    End Sub

    Private Sub VoitureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VoitureToolStripMenuItem.Click
        voiture.Show()
    End Sub

    Private Sub LesSortiesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LesSortiesToolStripMenuItem.Click
        consulttsorti.Show()
    End Sub

    Private Sub TypeDentretienToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TypeDentretienToolStripMenuItem.Click
        typentretien.Show()
    End Sub

    Private Sub CmdAnnuler_Click(sender As Object, e As EventArgs) Handles CmdAnnuler.Click
        On Error GoTo Gesterr
        If L.RecordCount = 0 Then
            CmdEnregistrer.Enabled = True
            CmdNvo.Enabled = True

        Else

            CmdEnregistrer.Enabled = True
            CmdNvo.Enabled = True

        End If

        Exit Sub
Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub CmdNvo_Click(sender As Object, e As EventArgs) Handles CmdNvo.Click


        CmdEnregistrer.Enabled = False
        CmdAnnuler.Enabled = False

        Combotypentr.Text = ""
        Textmtntent.Text = ""
        TextDat.Text = ""
        Combotypentr.Focus()
    End Sub

    Private Sub Entretien_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error GoTo Gesterr
        'Connecter()

        L.ActiveConnection = db
        L.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        Larequete = "Select * From Tentr"""
        L.Open(Larequete, , ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)
        Combotypentr.Items.Clear()


        If L.RecordCount > 0 Then


            TextDat.Text = ""
            Combotypentr.Text = ""
            Textmtntent.Text = DateTime.Today

        End If



        Exit Sub

Gesterr:
        MsgBox("Données erronnées!" & " Numéro erreur :" & Err.Number & "Description Erreur :" & Err.Description)
    End Sub

    Private Sub CmdEnregistrer_Click(sender As Object, e As EventArgs) Handles CmdEnregistrer.Click
        Dim p1 As Integer

        p1 = vbNull


        p1 = CInt(InStr(1, Combotypentr.Text, " "))


        If p1 > 0 Then
            Combotypentr.Text = Mid(Combotypentr.Text, 1, (CInt(p1) - 1))
        End If



        If Combotypentr.Text = "" Then
            MsgBox("Choisissez le numéro du type d'entretien", vbInformation)
            Combotypentr.Focus()
            Exit Sub
        End If



        If TextDat.Text = "" Then
            MsgBox("Saisissez la date de l'entretien", vbInformation)
            TextDat.Focus()
            Exit Sub
        End If

        If Not IsNumeric(Textmtntent.Text) Then
            MsgBox("Le montant saisi doit être numérique", vbInformation)
            Textmtntent.Focus()
            Exit Sub
        End If

        Do While Not L.EOF
            reponse = MsgBox("Voulez-vous enregistrer les données?", MsgBoxStyle.YesNo, "Stockage de données")
            If reponse = vbYes Then
                L.AddNew()
                L(0).Value = Combotypentr.Text
                L(1).Value = Textmtntent.Text
                L(2).Value = TextDat.Text
                L.Update()
                MsgBox("Ajout de données réussi!", MsgBoxStyle.Information, "Enregistrement")
                CmdNvo_Click(CmdNvo, e)
                Exit Sub
            Else
                Exit Sub
            End If
            L.MoveNext()
        Loop
    End Sub

    Private Sub NouvelleSortieToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NouvelleSortieToolStripMenuItem.Click
        nouvellesortie.Show()
    End Sub
End Class