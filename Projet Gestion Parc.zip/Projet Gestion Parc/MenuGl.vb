﻿Public Class MenuGl
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub ConducteurToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConducteurToolStripMenuItem.Click
        conducteur.Show()
    End Sub

    Private Sub MotifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MotifToolStripMenuItem.Click
        motif.Show()
    End Sub

    Private Sub VoitureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VoitureToolStripMenuItem.Click
        voiture.Show()
    End Sub

    Private Sub LesSortiesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LesSortiesToolStripMenuItem.Click
        consulttsorti.Show()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        nouvellesortie.Show()
    End Sub

    Private Sub MenuGl_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Connecter()
    End Sub

    Private Sub NouvelleSotieToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NouvelleSotieToolStripMenuItem.Click
        nouvellesortie.Show()
    End Sub
End Class