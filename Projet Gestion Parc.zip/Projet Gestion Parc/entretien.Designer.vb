﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Entretien
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Entretien))
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.CmdEnregistrer = New System.Windows.Forms.Button()
        Me.CmdNvo = New System.Windows.Forms.Button()
        Me.CmdAnnuler = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Combotypentr = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Textmtntent = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ConsultationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LesSortiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.GestionDesAjoutsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AjouterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConducteurToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MotifToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoitureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TypeDentretienToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextDat = New System.Windows.Forms.DateTimePicker()
        Me.NouvelleSortieToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.BindingNavigator1.CountItem = Me.BindingNavigatorCountItem
        Me.BindingNavigator1.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem})
        Me.BindingNavigator1.Location = New System.Drawing.Point(0, 0)
        Me.BindingNavigator1.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.BindingNavigator1.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.BindingNavigator1.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.BindingNavigator1.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.BindingNavigatorPositionItem
        Me.BindingNavigator1.Size = New System.Drawing.Size(667, 25)
        Me.BindingNavigator1.TabIndex = 24
        Me.BindingNavigator1.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Ajouter nouveau"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Nombre total d'éléments"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Supprimer"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Placer en premier"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Position actuelle"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Déplacer vers le bas"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Placer en dernier"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Tomato
        Me.Button2.Location = New System.Drawing.Point(639, 0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(27, 23)
        Me.Button2.TabIndex = 30
        Me.Button2.Text = "X"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.CmdEnregistrer)
        Me.Panel4.Controls.Add(Me.CmdNvo)
        Me.Panel4.Controls.Add(Me.CmdAnnuler)
        Me.Panel4.Location = New System.Drawing.Point(247, 263)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(393, 55)
        Me.Panel4.TabIndex = 35
        '
        'CmdEnregistrer
        '
        Me.CmdEnregistrer.BackColor = System.Drawing.Color.OliveDrab
        Me.CmdEnregistrer.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdEnregistrer.ForeColor = System.Drawing.Color.Silver
        Me.CmdEnregistrer.Location = New System.Drawing.Point(251, 11)
        Me.CmdEnregistrer.Name = "CmdEnregistrer"
        Me.CmdEnregistrer.Size = New System.Drawing.Size(97, 33)
        Me.CmdEnregistrer.TabIndex = 2
        Me.CmdEnregistrer.Text = "Enregistrer"
        Me.CmdEnregistrer.UseVisualStyleBackColor = False
        '
        'CmdNvo
        '
        Me.CmdNvo.BackColor = System.Drawing.Color.OliveDrab
        Me.CmdNvo.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdNvo.ForeColor = System.Drawing.Color.Silver
        Me.CmdNvo.Location = New System.Drawing.Point(148, 11)
        Me.CmdNvo.Name = "CmdNvo"
        Me.CmdNvo.Size = New System.Drawing.Size(97, 33)
        Me.CmdNvo.TabIndex = 1
        Me.CmdNvo.Text = "Nouveau"
        Me.CmdNvo.UseVisualStyleBackColor = False
        '
        'CmdAnnuler
        '
        Me.CmdAnnuler.BackColor = System.Drawing.Color.OliveDrab
        Me.CmdAnnuler.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdAnnuler.ForeColor = System.Drawing.Color.Silver
        Me.CmdAnnuler.Location = New System.Drawing.Point(45, 11)
        Me.CmdAnnuler.Name = "CmdAnnuler"
        Me.CmdAnnuler.Size = New System.Drawing.Size(97, 33)
        Me.CmdAnnuler.TabIndex = 0
        Me.CmdAnnuler.Text = "Annuler"
        Me.CmdAnnuler.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Combotypentr)
        Me.GroupBox2.Controls.Add(Me.Panel1)
        Me.GroupBox2.Controls.Add(Me.Panel2)
        Me.GroupBox2.Controls.Add(Me.Textmtntent)
        Me.GroupBox2.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Gainsboro
        Me.GroupBox2.Location = New System.Drawing.Point(247, 77)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(393, 180)
        Me.GroupBox2.TabIndex = 34
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Entretien"
        '
        'Combotypentr
        '
        Me.Combotypentr.BackColor = System.Drawing.Color.Chocolate
        Me.Combotypentr.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Combotypentr.ForeColor = System.Drawing.Color.LightGray
        Me.Combotypentr.FormattingEnabled = True
        Me.Combotypentr.Location = New System.Drawing.Point(74, 48)
        Me.Combotypentr.Name = "Combotypentr"
        Me.Combotypentr.Size = New System.Drawing.Size(254, 33)
        Me.Combotypentr.TabIndex = 35
        Me.Combotypentr.Text = "Type d'entretien"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel1.Location = New System.Drawing.Point(74, 82)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(254, 10)
        Me.Panel1.TabIndex = 34
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel2.Location = New System.Drawing.Point(74, 131)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(254, 10)
        Me.Panel2.TabIndex = 20
        '
        'Textmtntent
        '
        Me.Textmtntent.BackColor = System.Drawing.Color.Chocolate
        Me.Textmtntent.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Textmtntent.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Textmtntent.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textmtntent.ForeColor = System.Drawing.Color.LightGray
        Me.Textmtntent.Location = New System.Drawing.Point(74, 98)
        Me.Textmtntent.Name = "Textmtntent"
        Me.Textmtntent.Size = New System.Drawing.Size(254, 20)
        Me.Textmtntent.TabIndex = 19
        Me.Textmtntent.Text = "Montant"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.MenuStrip1)
        Me.GroupBox1.Controls.Add(Me.MenuStrip2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 86)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(229, 75)
        Me.GroupBox1.TabIndex = 33
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Menu Général"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConsultationsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(3, 40)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(223, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ConsultationsToolStripMenuItem
        '
        Me.ConsultationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LesSortiesToolStripMenuItem})
        Me.ConsultationsToolStripMenuItem.Name = "ConsultationsToolStripMenuItem"
        Me.ConsultationsToolStripMenuItem.Size = New System.Drawing.Size(92, 20)
        Me.ConsultationsToolStripMenuItem.Text = "Consultations"
        '
        'LesSortiesToolStripMenuItem
        '
        Me.LesSortiesToolStripMenuItem.Name = "LesSortiesToolStripMenuItem"
        Me.LesSortiesToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.LesSortiesToolStripMenuItem.Text = "les sorties"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GestionDesAjoutsToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(3, 16)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(223, 24)
        Me.MenuStrip2.TabIndex = 1
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'GestionDesAjoutsToolStripMenuItem
        '
        Me.GestionDesAjoutsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AjouterToolStripMenuItem})
        Me.GestionDesAjoutsToolStripMenuItem.Name = "GestionDesAjoutsToolStripMenuItem"
        Me.GestionDesAjoutsToolStripMenuItem.Size = New System.Drawing.Size(115, 20)
        Me.GestionDesAjoutsToolStripMenuItem.Text = "Gestion des ajouts"
        '
        'AjouterToolStripMenuItem
        '
        Me.AjouterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConducteurToolStripMenuItem, Me.MotifToolStripMenuItem, Me.VoitureToolStripMenuItem, Me.TypeDentretienToolStripMenuItem, Me.NouvelleSortieToolStripMenuItem})
        Me.AjouterToolStripMenuItem.Name = "AjouterToolStripMenuItem"
        Me.AjouterToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AjouterToolStripMenuItem.Text = "Ajouter"
        '
        'ConducteurToolStripMenuItem
        '
        Me.ConducteurToolStripMenuItem.Name = "ConducteurToolStripMenuItem"
        Me.ConducteurToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ConducteurToolStripMenuItem.Text = "conducteur"
        '
        'MotifToolStripMenuItem
        '
        Me.MotifToolStripMenuItem.Name = "MotifToolStripMenuItem"
        Me.MotifToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.MotifToolStripMenuItem.Text = "motif"
        '
        'VoitureToolStripMenuItem
        '
        Me.VoitureToolStripMenuItem.Name = "VoitureToolStripMenuItem"
        Me.VoitureToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.VoitureToolStripMenuItem.Text = "voiture"
        '
        'TypeDentretienToolStripMenuItem
        '
        Me.TypeDentretienToolStripMenuItem.Name = "TypeDentretienToolStripMenuItem"
        Me.TypeDentretienToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TypeDentretienToolStripMenuItem.Text = "type d'entretien"
        '
        'TextDat
        '
        Me.TextDat.Location = New System.Drawing.Point(440, 60)
        Me.TextDat.Name = "TextDat"
        Me.TextDat.Size = New System.Drawing.Size(200, 20)
        Me.TextDat.TabIndex = 36
        '
        'NouvelleSortieToolStripMenuItem
        '
        Me.NouvelleSortieToolStripMenuItem.Name = "NouvelleSortieToolStripMenuItem"
        Me.NouvelleSortieToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.NouvelleSortieToolStripMenuItem.Text = "nouvelle sortie"
        '
        'Entretien
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Chocolate
        Me.ClientSize = New System.Drawing.Size(667, 338)
        Me.Controls.Add(Me.TextDat)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.BindingNavigator1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Entretien"
        Me.Text = "entretien"
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BindingNavigator1 As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents Button2 As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents CmdEnregistrer As Button
    Friend WithEvents CmdNvo As Button
    Friend WithEvents CmdAnnuler As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Textmtntent As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ConsultationsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LesSortiesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents GestionDesAjoutsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AjouterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConducteurToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MotifToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VoitureToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TextDat As DateTimePicker
    Friend WithEvents Combotypentr As ComboBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TypeDentretienToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NouvelleSortieToolStripMenuItem As ToolStripMenuItem
End Class
